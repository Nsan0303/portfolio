import os

def upload_article():
    """記事アップロードシステム"""
    #ディレクトリ指定
    dir = input("please enter the directory: ")
    print(dir)

    #記事のタイトル名
    title = input("please enter the article title: ")
    print(title)

    #記事の説明
    description = input("please enter the article description: ")
    print(description)
    
    

