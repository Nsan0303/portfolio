import os 

def delete_article():
    print("test")