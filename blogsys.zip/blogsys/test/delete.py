import os
import mysql.connector  # MySQL接続用
from dotenv import load_dotenv  # .envファイルの読み込み

# .envファイルの絶対パスを取得し、環境変数をロード
env_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '.env'))
load_dotenv(dotenv_path=env_path)
DB_HOST = os.getenv('DB_HOST', 'localhost')
DB_USER = os.getenv('DB_USER', 'root')
DB_PASSWORD = os.getenv('DB_PASSWORD', '')
DB_NAME = os.getenv('DB_NAME', 'blog_db')

def delete_article():
    # DB上で指定IDの記事の公開設定(publicity)を'private'に変更する
    print("=== 記事非公開処理 ===")
    article_id = input("非公開にしたい記事のIDを入力してください: ").strip()
    try:
        conn = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME
        )
        cur = conn.cursor()
        # 公開設定を'private'に更新
        cur.execute("UPDATE URL_list_table SET publicity='private' WHERE id=%s", (article_id,))
        conn.commit()
        print(f"ID:{article_id} の記事を非公開にしました。")
        cur.close()
        conn.close()
    except Exception as e:
        print(f"DB更新エラー: {e}")